create view supply_classification_null as
select `classification`.`supply_classification`.`id`                   AS `id`,
       `classification`.`supply_classification`.`manufacturer_number`  AS `manufacturer_number`,
       `classification`.`supply_classification`.`created`              AS `created`,
       `classification`.`supply_classification`.`modified`             AS `modified`,
       `classification`.`supply_classification`.`cage_approach_id`     AS `cage_approach_id`,
       `classification`.`supply_classification`.`manufacturer_id`      AS `manufacturer_id`,
       `classification`.`supply_classification`.`hospital_supply_name` AS `hospital_supply_name`,
       `classification`.`supply_classification`.`cost`                 AS `cost`,
       `classification`.`supply_classification`.`total_cost`           AS `total_cost`,
       `classification`.`supply_classification`.`supply_name_id`       AS `supply_name_id`,
       `classification`.`supply_classification`.`times_used`           AS `times_used`,
       `classification`.`supply_classification`.`checked`              AS `checked`,
       `classification`.`supply_classification`.`hospital_id`          AS `hospital_id`,
       `classification`.`supply_classification`.`score`                AS `score`
from `classification`.`supply_classification`
where (isnull(`classification`.`supply_classification`.`hospital_supply_name`) or
       isnull(`classification`.`supply_classification`.`supply_name_id`));

